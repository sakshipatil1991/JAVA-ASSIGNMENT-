
class Student {
    String name;
    int age;
    String department;

    Student() {
        name = "Unknown";
        age = 20;
        department = "Unassigned";
    }

    Student(String name, int age) {
        this.name = name;
        this.age = age;
        department = "IT";
    }

    Student(String name, int age, String department) {
        this.name = name;
        this.age = age;
        this.department = department;
    }

    void printDetails() {
        System.out.println(name + " " + age + " " + department);
    }
}

public class Inherit2{
    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = new Student("sakshi", 21);
        Student s3 = new Student("Priyanka", 22, "Computer science");

        s1.printDetails();
        s2.printDetails();
        s3.printDetails();
    }
}
