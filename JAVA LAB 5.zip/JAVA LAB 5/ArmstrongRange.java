
import java.util.Scanner;

public class ArmstrongRange {
    public static void printArmstrongNumber(int start, int end) {
        for (int i = start; i <= end; i++) {
            int num = i, sum = 0;
            while (num > 0) {
                int digit = num % 10;
                int cube = digit * digit * digit;
                sum += cube;
                num = num / 10;
            }
            if (sum == i) {
                System.out.println(i);
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int start = sc.nextInt();
        int end = sc.nextInt();
        printArmstrongNumber(start, end);
    }
}
